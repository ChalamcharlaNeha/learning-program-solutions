package com.factory;

public interface Document {
	void open();
}
