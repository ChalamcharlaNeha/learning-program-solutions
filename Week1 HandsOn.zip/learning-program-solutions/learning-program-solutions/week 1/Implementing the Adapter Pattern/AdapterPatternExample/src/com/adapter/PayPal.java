package com.adapter;

public class PayPal {
	public void makePayment(String amount) {
        System.out.println("Paid " + amount + " using PayPal");
    }
}
